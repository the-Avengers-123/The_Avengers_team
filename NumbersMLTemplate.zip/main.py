from mlnumbers import classifyNumbers, storeNumbers
from mlmodel import trainModel, checkModel



API_KEY="84e4ae10-83e9-11eb-8720-cbbb1b200c7ee331bfae-cf39-4f16-a6c7-91b84590d0db"


# -------------------------------------------------------
# CHECK IF THE MACHINE LEARNING MODEL IS READY TO USE
# -------------------------------------------------------

# you can use this to check if your machine learning model
# has finished training 

status = checkModel(API_KEY)
print (status)




# -------------------------------------------------------
# USE YOUR MACHINE LEARNING MODEL TO RECOGNIZE NUMBERS 
# -------------------------------------------------------

## CHANGE THIS to the data that you want your 
# machine learning model to classify
data1 =float(input("Please Enter the amount of oxygen :  "))
data2 = float(input("Please Enter the temperature : "))
data3 = input("If you wear a medical mask, answer yes,otherwise answer no: ")
data4 = float(input("Please Enter the distance between another people : "))

test_data = [ data1, data2, data3, data4 ]

demo = classifyNumbers(API_KEY, test_data)

label = demo["class_name"]
confidence = demo["confidence"]

# CHANGE THIS to do something different with the result
print ("result: '%s' with %d%% confidence" % (label, confidence))
print("Thank you ")

# -------------------------------------------------------
# ADD TRAINING EXAMPLES TO YOUR MACHINE LEARNING PROJECT
# -------------------------------------------------------

# CHANGE THIS to the data that you want to add 
# to your project training data
data1 = 0
data2 = 0
data3 = "yes"
data4 = 0

training_data = [ data1, data2, data3, data4 ]

# CHANGE THIS to the training bucket to add the
# training example to
training_label = "safe"

# remove the comment on the next line to use this 
storeNumbers(API_KEY, training_data, training_label)




# -------------------------------------------------------
# TRAIN A NEW MACHINE LEARNING MODEL
# -------------------------------------------------------

# after collecting new training examples, you can use 
# to train a new machine learning model 

# remove the comment on the next line to use this 
# trainModel(API_KEY)
